---
title: "Install: Operations as Code"
type: guide
audience: internal
---

# Install: Operations as Code

Ten minutes. One folder, one repo, for one business.

You already ran Self as Code in your own private repo. This is the second
package: the business, written down. Where two people share a business, do
this once, at one laptop; the second person joins through GitHub afterwards.

## Steps

1. Download `operations-as-code-pack.zip` from the Resources tab of your HQ.
2. Unzip it somewhere you will find it again, and rename the folder after the
   business, ending in `-ops`:
   ```bash
   cd ~
   unzip ~/Downloads/operations-as-code-pack.zip
   mv operations-as-code-pack acme-ops
   ```
   Windows: unzip into `Documents\acme-ops`.
3. Open Claude Code in that folder and paste the installer prompt below.
4. When it says it is done, restart Claude Code, run `/install`, then `/oac`.

**Done looks like:** the folder has a git history, the bottom line of Claude
Code says `OAC`, typing `oac` in a new Terminal window opens this folder with
Claude Code running, `/install` has shown you a fill-map, and `/oac` has
written `systems/register.md` with a manual-process count you can say out loud.

---

## The installer prompt (paste everything below into Claude Code, running in the folder)

Hi Claude. OpsCode sent me this pack to install my business's Operations as
Code repo, which is sitting in this folder. Do these steps in order and tell me
what you did after each one.

1. **Verify the layout.** Confirm this folder contains `CLAUDE.md`,
   `README.md`, `CHANGELOG.md`, `INSTALL.md`, `STATUSLINE.md`, `MODES.md`,
   `.oac/`, `.claude/commands/`, `.githooks/`, `scripts/`, `specs/`,
   `decisions/`, `systems/`, `team/` and `context-core/`. If anything is
   missing, stop and tell me.
2. **Name the business, and me.** Ask me the business name, then put it into
   the `title` of `README.md` and `CLAUDE.md` where they say 'this business'.
   Ask me my first name and create `team/<firstname>/` with an empty `logs/`
   folder inside it (put a `.gitkeep` in `logs/`). Ask me the name of my own
   private repo (it ends in `-ops`) and put it in `.oac/manifest.yml` as
   `parent_operation`. If I do not have one yet, leave the placeholder and
   tell me.
3. **Initialise git, with the hook.** Run `git init -b main`, then
   `git config core.hooksPath .githooks`, then add everything and commit as
   `Operations as Code: day one`. If there is already a `.git`, leave it
   alone and say so. If the hook warns that gitleaks is not installed, tell
   me the install command for my platform and carry on.
4. **Install the bottom line.** `python3 scripts/install-oac-statusline.py`
   and report what it did.
5. **Install the one word.** `bash scripts/install-shortcuts.sh` and tell me
   what it printed. From then on, a new Terminal window and the word `oac`
   opens this folder with Claude Code running.
6. **Run the validator.** `python3 scripts/oac-validate.py .` Report the
   conformance level and the top three things it flags. Do not fix them yet.
7. **Read `CLAUDE.md`** and give me a three-line summary of what this repo is
   for and what its two halves are.
8. **Tell me you are done**, and what happens next, in order: Claude Code may
   ask me to approve this project's settings, and I should approve them; then
   I fully restart Claude Code; then I run `/install`, then `/oac`. To get
   back here any day, I open a new Terminal window and type `oac`. Every
   session after that starts with `/start` and ends with `/done`.

Do not edit any other file contents during this install. Install only.
